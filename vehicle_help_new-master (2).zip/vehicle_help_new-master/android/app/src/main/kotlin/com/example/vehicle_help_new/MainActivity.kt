package com.example.vehicle_help_new

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
